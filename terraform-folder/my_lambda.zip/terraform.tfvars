aws_region = "eu-central-1"
key_name = "aws_grocery_ec2_key"
my_ip = "83.135.4.32/32"
my_profile = "AdministratorAccess-537124969656"